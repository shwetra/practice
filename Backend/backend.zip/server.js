require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connection = require('./db/db'); // ✅ import the existing connection

const app = express();
app.use(cors());
app.use(express.json());

app.get('/users', (req, res) => {
  connection.query('SELECT * FROM users', (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
 